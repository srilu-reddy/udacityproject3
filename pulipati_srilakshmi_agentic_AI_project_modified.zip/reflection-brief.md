# Reflection Brief — Evaluation and Observability Capstone

**Name:** pulipati srilakshmi  
**Date:** 2026-10-27

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste
> it from your artifacts — a reviewer should be able to find it. Answers that are correct in the
> abstract but cite nothing do not meet the bar. Keep it short and specific.

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Debian GNU/Linux 12 (bookworm), kernel 6.6.97+ x86_64 (Udacity/Vocareum workspace) — `environment.txt` |
| Python version | Python 3.13.0 — `environment.txt` |
| Date run | 2026-10-27 |
| Ran any system live? (which) | No. Workspace had no `ANTHROPIC_API_KEY`, therefore System 1 executed the offline fallback path documented in `tests/test_us04_routing.py`; System 2 was invoked with `--mode replay`; System 3 used `--offline`. |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | `45 passed, 3 skipped` (skipped items are the three `test_live_*` cases) — `01-policy-pipeline/tests.txt` |
| Routing output file | `01-policy-pipeline/routing_decisions.json` (produced by `test_ac_04_05_routing_decisions_written_to_json_file` and retained through `--basetemp`; see `pipeline-run.txt`) |
| auto_approve / human_review / spot_check counts | 1 / 1 / 0 (fallback contains two entries: `POL-SL1` auto_approve, `POL-SL2` human_review; spot-check sampling is covered by the `test_ac_04_03_*` suite and does not appear in this file) |

**1a. Retry boundary.** From your perturbation run (a required field removed), paste the escalation
record. How many API calls did the system make, and why is retrying a futile case worse than
escalating it?

> From `01-policy-pipeline/perturbation/own-perturbation.txt`:  
> `result=RetryFutileEscalation api_calls=1 queued_responses=4 {'field': 'premium_amount', 'detected_pattern': 'premium_amount_absent', 'reason': "Field 'premium_amount' returned null — the source document does not contain this information. Retry is futile; escalate to human review."}`  
> The system issued **exactly one** call despite four canned responses being available and `max_retries=3`. The unit test confirms the same (`assert client.call_count == 1` in `retry-tests.txt`). When a required field is truly absent, further retries cannot invent missing source data. Extra attempts only consume latency and tokens; worse, the retry prompt may push the model to invent a plausible number, converting an honest absence into fabricated premium data. By comparison, the format-error case (`premium_amount=-1500.0`) required two calls and recovered successfully because the information existed and only needed reformatting.

**1b. Reading the router.** Pick one `human_review` record from your routing output. Which of the
three signals (confidence, reviewer, integration) sent it to a human? If you had trusted the model's
confidence alone, what would have happened?

> Record `POL-SL2` (home policy): decision `"human_review"`, reason `"fields_below_threshold=['premium_amount']"`, confidence on that field = 0.5, empty reviewer_disagreements and integration_failures lists.  
> Only the **confidence** signal triggered the human route. In this particular case the model itself reported low confidence, so a pure-confidence gate would have behaved the same. The danger appears when the model is both confident and wrong: the calibration slice for umbrella exclusions shows conf=0.93 / acc=0.00. Those records would sail through any confidence-only threshold. That is precisely why the router also demands reviewer agreement and clean integration checks (see `test_ac_04_06_high_confidence_plus_reviewer_disagreement_still_routes_to_human_review PASSED` in `tests.txt`).

**1c. Where the aggregate lies.** Run the calibration snippet. Quote the one cell whose accuracy lags
its confidence, plus the overall figure. What does slicing by `policy_type × field` catch that a
single number hides?

> From `01-policy-pipeline/calibration-report.txt`:  
> `umbrella  exclusions      n=2 conf=0.93 acc=0.00 brier=0.865`  
> `OVERALL brier=0.291`  
> The aggregate Brier score looks acceptable because the well-calibrated cells (auto / premium_amount with acc=1.00 and near-zero Brier) dominate the average. Only the cross-tabulation reveals a systematic failure confined to one policy type and one field. That pattern points to a real distribution shift (umbrella exclusion language differing from training) rather than random noise, and it tells an operator exactly where to tighten thresholds or add review.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | `25 passed` — `02-mortgage-extraction/tests.txt` |
| Document run | `fixtures/documents/income_sum_mismatch.txt` (`discrepancy-run.txt`); also `appraisal_informal_sqft.txt` and `income_missing_bonus.txt` (`extract-run.txt`) |
| Classified type | `classify: ... type=income_verification` → `extract: ... tool=extract_income_verification` (appraisal documents map to `type=appraisal` → `tool=extract_appraisal`) |

**2a. Two guarantees.** Paste your discrepancy-run output. Tool use already forces valid JSON, yet the
validator still catches a bad sum. Why are these two different guarantees? Name one error each cannot
catch.

> From `02-mortgage-extraction/discrepancy-run.txt`:  
> extraction is schema-valid yet the validator reports `"consistent": false`, `"calculated": 9642.17`, `"stated": 10892.17`, `"delta": -1250.0`.  
> Tool/schema enforcement guarantees structural well-formedness and type correctness; it cannot detect that the arithmetic relationship among the numbers is false. The independent validator guarantees that the stated total matches the sum of the parts (within tolerance); it cannot catch a missing field that was never emitted or a semantic mis-mapping that still produces numbers of the right type. The two layers therefore complement each other: schema stops malformed objects, the arithmetic check stops plausible-looking but inconsistent objects.

**2b. Refusing to fabricate.** Run on a document missing a field. Paste that field's output. Why null
instead of an invented value? Point to the schema choice that allows it.

> From `02-mortgage-extraction/extract-run.txt` (document `income_missing_bonus.txt`):  
> `"base_monthly": 5673.08, "bonus_monthly": null, "bonus_ytd": null`  
> Because the source document contains no bonus figures, emitting null is the truthful answer. Inventing a number would inject false income into a loan file and appear more trustworthy than an empty field. The schema permits this outcome by declaring the bonus fields **nullable**; the model is therefore never forced to populate a required numeric slot. The corresponding unit test (`test_ac_03_03_missing_bonus_returns_none PASSED`) confirms the behavior. Null also keeps the validator honest: it only performs the sum check when both sides are non-null.

**2c. Normalization.** Quote one field where the source text and extracted value differ in format
("about 2,400 sq ft" → `2400`). Why normalize at extraction time rather than downstream?

> Source text (appraisal fixture, line ~37): `Gross Living Area: approximately 2,400 sq ft (above-grade finished)`.  
> Extracted value: `"gross_living_area_sqft": 2400`.  
> The same document contains several other square-footage figures (lot, basement, garage). The model correctly selected the GLA figure and converted informal phrasing plus commas into a plain integer. Performing normalization once, at extraction time, means every downstream consumer receives a single typed number instead of re-implementing its own fragile parsers for “approximately”, “~”, and thousands-separators. Because the model is the only component that still sees the original surrounding context and labels, it is the natural place to resolve ambiguity. Centralizing the rules in one constant (verified by `test_ac_03_05_normalization_rules_is_single_referenced_constant PASSED`) prevents those rules from drifting across consumers.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | `34 passed` — `03-supply-chain/tests.txt` |
| Briefing file | `03-supply-chain/briefing.md` (generated by the run recorded in `investigation-run.txt`) |
| Section the conflict landed in | `## Contested` — `on_time_delivery_rate [2 sources, conflicting] ⚠️ ESCALATE` |

**3a. Annotate, don't arbitrate.** Quote one conflicting-metric pair from your briefing — both values,
sources, dates. Give one way a reader is better served by the preserved conflict than by a single
“winner” value.

> `on_time_delivery_rate`: 95.0 % (supplier_audit, as of 2026-04-10) versus 78.0 % (logistics, as of 2026-04-12).  
> Keeping both numbers and the sources visible lets a reader see the discrepancy and decide whether to investigate the logistics feed, the audit methodology, or a real operational problem. Collapsing to a single “winner” would hide the disagreement and could produce a false sense of certainty.

**3b. Timeout behavior.** After forcing a source timeout, what changed in the briefing? Quote the
relevant lines and note any surprising side-effect.

> Banner: `Sources unavailable: logistics unavailable (timeout)`.  
> `late_shipment_count` moved under `## Incomplete` with the annotation `_ [missing source: timeout reading logistics]_`.  
> Unexpectedly, `on_time_delivery_rate` left the Contested section and appeared under `## Well-Established` as a single-source 95 % figure; the previous conflict and escalation flag disappeared. A missing source can therefore silence a disagreement rather than merely degrade coverage. A reader who only looks at the metric sections (and skips the top banner) would now see an unrealistically clean on-time rate.

**3c. Provenance and incompleteness.** How does the system make incompleteness visible without
inventing values? Point to a concrete example from the timeout run.

> Metrics that depended solely on the timed-out logistics source are placed in the `## Incomplete` section and carry an explicit missing-source annotation. No placeholder numbers are generated. Example: `late_shipment_count` is shown only as incomplete with the timeout note; it is never given a synthetic default. That design preserves honesty about what the system actually knows.

---

## 4. Synthesis

**4a. One principle.** Name the single moment in your runs (system + artifact) where *evaluate the
output, don't trust the model's word* most clearly caught something a trusting design would have
shipped.

> System 2, artifact `02-mortgage-extraction/discrepancy-run.txt`. The extraction was fully schema-valid and contained a stated monthly total of 10892.17. The independent arithmetic validator nevertheless reported a $1,250 shortfall relative to the line items. A design that trusted the model’s (or the document’s) stated total would have forwarded inflated income to underwriting. The model had faithfully transcribed the document; only the separate check revealed that the document’s own arithmetic was wrong.

**4b. Confidence ≠ correctness.** Pick the system where this mattered most, and explain why using
something you observed.

> System 1. The calibration report cell `umbrella exclusions conf=0.93 acc=0.00` shows the model repeatedly expressing high confidence while being completely wrong. A pure confidence threshold of 0.90 would have auto-approved every one of those records. The router mitigates the risk by requiring three independent signals (confidence, reviewer agreement, integration health) and by applying stratified spot-checks to the auto-approved population, so systematic high-confidence errors remain visible in calibration.

**4c. Apply it.** Describe a real workflow where an LLM pulls structured results from messy input.
Which pattern — validated retry with escalation, independent review with deterministic routing, or
provenance-preserving conflict annotation — would you reach for first, and what would you instrument
to know when it broke?

> Concrete workflow: ingesting supplier invoices (PDF or email) into an accounts-payable system — extracting vendor, invoice number, date, line items, tax, and total.  
> I would start with **validated retry plus escalation**, augmented by a System-2-style arithmetic guard (line items + tax must equal the stated total within a tight tolerance). Missing critical identifiers (PO number, invoice number) should return null and route to a human rather than being guessed.  
> Instrumentation I would add:  
> - escalation rate and retry-count histogram broken down by vendor (a sudden jump signals a layout change);  
> - discrepancy rate per vendor;  
> - a sliced calibration table (vendor × field) built from sampled human reviews, because a single vendor’s tax line can fail systematically while overall accuracy still looks healthy;  
> - an alert on any change to the tolerance configuration, because the System-2 perturbation demonstrated that widening the tolerance silently disables the safety check.
