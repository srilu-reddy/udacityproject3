# Perturbation Log

All experiments were performed offline (no live API key present in the workspace). Commands and key output lines are preserved under each system folder.

### System 1 — validated, routed pipeline

- **Change I made (file + what I changed):** Custom offline experiment using the suite’s `RecordedClient`. Starting from a clean extraction for policy `POL-2026-087`, I removed a required field that the course test does not blank (`premium_amount=None`; the official test blanks `endorsements`). Four identical null responses were queued so any unnecessary retries would be visible in the call counter. As a control I also injected a recoverable format error (`premium_amount=-1500.0`) followed by a corrected response.
- **Command I ran:** `.venv/bin/python - <<'PY' ... extract_with_retry(client=RecordedClient(...), policy_id="POL-2026-087", ..., max_retries=3) ... PY` (full transcript: `01-policy-pipeline/perturbation/own-perturbation.txt`). Supporting course test output: `.venv/bin/pytest tests/test_us01_retry.py -v` → `01-policy-pipeline/perturbation/retry-tests.txt`.
- **What I predicted:** A genuinely missing required field should cause immediate escalation after a single call rather than consuming the three allowed retries. The negative-premium format error should be retried once and then succeed.
- **What actually happened (paste the key output line):**  
  `B) PERTURBED: premium_amount=None (value genuinely absent) → result=RetryFutileEscalation api_calls=1`  
  Format-error case recovered on the second call as expected.
- **How this differs from the unperturbed run:** Unperturbed extraction succeeds on the first call. The null case correctly refused to retry; the format-error case demonstrated that the retry path still works when the underlying information is present.

### System 2 — schema-enforced two-pass extraction

- **Change I made (file + what I changed):** Two controlled experiments.  
  (A) Replayed the income-sum-mismatch document after correcting the stated total so the arithmetic becomes consistent.  
  (B) Raised the validator tolerance from the default to 1500 while leaving the original $1,250 discrepancy in place.
- **Command I ran:** Replay + corrected total → `02-mortgage-extraction/perturbation/run-A-replay.txt`; tolerance experiment → `02-mortgage-extraction/perturbation/run-B-validator.txt`. Original discrepant run remains in `discrepancy-run.txt`.
- **What I predicted:** Correcting the total should clear the inconsistency flag. Raising tolerance above the actual delta should cause the same arithmetic error to be reported as consistent.
- **What actually happened (paste the key output line):**  
  Unperturbed / case A: `"consistent": false`, `"calculated": 9642.17`, `"stated": 10892.17`, `"delta": -1250.0`. After the total is fixed the flag disappears. Case B with tolerance=1500 reports `consistent=True` for the identical $1,250 error.
- **How this differs from the unperturbed run:** The original run correctly surfaces the arithmetic mismatch. Case A proves the validator is reacting to the numbers rather than to some document-level property. Case B shows that the tolerance parameter is a silent safety switch; a careless configuration change can disable the check entirely. Replay also fails loudly on previously unseen input instead of returning a cached or invented extraction.

### System 3 — multi-source synthesis

- **Change I made (file + what I changed):** Forced the logistics source to time out via `--simulate-timeout`, then compared the resulting briefing with the baseline briefing.
- **Command I ran:** `.venv/bin/supply-chain-investigate meridian --offline --simulate-timeout` (output: `03-supply-chain/timeout-run.txt`, briefing: `perturbation/briefing-timeout.md`) and `diff -u briefing.md perturbation/briefing-timeout.md` (result: `perturbation/briefing-diff.txt`).
- **What I predicted:** The investigation completes, logistics is marked unavailable, and any metric that depended exclusively on logistics moves into the Incomplete section.
- **What actually happened (paste the key output line):**  
  `> Sources unavailable: logistics unavailable (timeout)`  
  `### late_shipment_count  _[missing source: timeout reading logistics]_` (under `## Incomplete`)  
  `## Contested` becomes empty; `on_time_delivery_rate` migrates to `## Well-Established` as a single-source 95 % figure. Exit code 0.
- **How this differs from the unperturbed run:** The expected degradation (banner + Incomplete section) occurred. The surprising side-effect is that a source outage can eliminate a prior conflict: the 78 % logistics value disappears, the remaining 95 % is promoted to Well-Established, and the escalation warning vanishes. A reader who skips the top banner would therefore see an artificially clean on-time rate. Recommended hardening: when a source drops, any metric that previously drew from it should be annotated in place as “reduced coverage” rather than silently changing category.
